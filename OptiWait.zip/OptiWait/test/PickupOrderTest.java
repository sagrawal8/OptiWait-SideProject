import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class PickupOrderTest {

  Menu menu;
  PickupOrder order;

  @Before
  public void init(){
    menu = new Menu();
    menu.addMenuItem(new FoodItem("Mozz Sticks", 5, FoodTypes.Appetizers));
    menu.addMenuItem(new FoodItem("Chicken Parm", 45, FoodTypes.Entree));
    menu.addMenuItem(new FoodItem("Vanilla IceCream", 3, FoodTypes.Desserts));
    menu.addMenuItem(new FoodItem("Coke", 2, FoodTypes.Beverages));
    menu.addMenuItem(new FoodItem("Pepsi", 2, FoodTypes.Beverages));
    order = new PickupOrder(menu);
  }

  @Test
  public void testConstructor(){

    assertTrue(order.getMenu() == menu);
    assertEquals("Order is empty.", order.toString());
  }

  @Test
  public void testAddOrderItem(){
    order.addOrderItem("Chicken Parm", 4);
    order.addOrderItem("Coke", 5);
    order.addOrderItem("Mozz sticks", 1);
    order.addOrderItem("Mozz sticks", 1);
    order.addOrderItem("Coke", 4);
    System.out.println(order.toString());
  }
}
