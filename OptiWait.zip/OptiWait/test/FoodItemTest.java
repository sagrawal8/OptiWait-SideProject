import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class FoodItemTest {

  @Test
  public void testConstructor(){
    FoodInterface food1 = new FoodItem("Mozz Sticks", 5, FoodTypes.Appetizers);
    assertEquals("Mozz Sticks", food1.getName());
    assertEquals(5, food1.getPrepTime(), 0);
    assertEquals(FoodTypes.Appetizers, food1.getType());

    FoodInterface food2 = new FoodItem("Chicken Parm", 45, FoodTypes.Entree);
    assertEquals("Chicken Parm", food2.getName());
    assertEquals(45, food2.getPrepTime(), 0);
    assertEquals(FoodTypes.Entree, food2.getType());

    FoodInterface food3 = new FoodItem("Vanilla IceCream", 3, FoodTypes.Desserts);
    assertEquals("Vanilla IceCream", food3.getName());
    assertEquals(3, food3.getPrepTime(), 0);
    assertEquals(FoodTypes.Desserts, food3.getType());

    FoodInterface food4 = new FoodItem("Coke", 2, FoodTypes.Beverages);
    assertEquals("Coke", food4.getName());
    assertEquals(2, food4.getPrepTime(), 0);
    assertEquals(FoodTypes.Beverages, food4.getType());

    System.out.println(food1);
    System.out.println(food2);
    System.out.println(food3);
    System.out.println(food4);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructor_NullName() {
    new FoodItem(null, 5, FoodTypes.Appetizers);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructor_EmptyName() {
    new FoodItem("", 5, FoodTypes.Appetizers);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructor_ZeroPrepTime() {
   new FoodItem("Mozz Sticks", 0, FoodTypes.Appetizers);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructor_NegativePrepTime() {
    new FoodItem("Mozz Sticks", -4, FoodTypes.Appetizers);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructor_NullType() {
    new FoodItem("Mozz Sticks", 3, null);
  }


}
