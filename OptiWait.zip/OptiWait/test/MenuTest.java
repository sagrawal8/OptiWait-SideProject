import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class MenuTest {

  MenuInterface menu;

  @Before
  public void init() {
    menu = new Menu();
  }

  @Test
  public void testMenuConstructor() {
    assertEquals("Menu is empty.", menu.toString());
  }

  @Test
  public void testAddMenuItem_Single() {
    menu.addMenuItem(new FoodItem("Mozz Sticks", 5, FoodTypes.Appetizers));

    assertEquals("Appetizers:\n"
        + "Mozz Sticks\n"
        + "------------------------", menu.toString());
  }

  @Test
  public void testAddMenuItem_Multiple() {
    menu.addMenuItem(new FoodItem("Mozz Sticks", 5, FoodTypes.Appetizers));
    menu.addMenuItem(new FoodItem("Chicken Parm", 45, FoodTypes.Entree));
    menu.addMenuItem(new FoodItem("Vanilla IceCream", 3, FoodTypes.Desserts));
    menu.addMenuItem(new FoodItem("Coke", 2, FoodTypes.Beverages));
    assertEquals(4, menu.getMenu().size());
  }

  @Test
  public void testRemoveMenuItem_NameAndType() {
    menu.addMenuItem(new FoodItem("Mozz Sticks", 5, FoodTypes.Appetizers));
    menu.addMenuItem(new FoodItem("Chicken Parm", 45, FoodTypes.Entree));
    menu.addMenuItem(new FoodItem("Vanilla IceCream", 3, FoodTypes.Desserts));
    menu.addMenuItem(new FoodItem("Coke", 2, FoodTypes.Beverages));
    menu.addMenuItem(new FoodItem("Pepsi", 2, FoodTypes.Beverages));
    menu.removeMenuItem("Mozz Sticks", FoodTypes.Appetizers);
    assertEquals(3, menu.getMenu().size());
    System.out.println(menu.toString());
  }

}
