public enum FoodTypes {
  Appetizers,
  Entree,
  Beverages,
  Desserts
}
