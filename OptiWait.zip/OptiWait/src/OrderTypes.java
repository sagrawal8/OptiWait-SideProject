public enum OrderTypes {
  PickUp,
  DineIn
}
